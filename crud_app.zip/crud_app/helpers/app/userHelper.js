const Employee = require('../../models/user');

exports.addUser = async function (user) {
    return new Promise(async (resolve, reject) => {
      try {
        await Employee.create(user);
        return resolve({
          statusCode: 201
          
        });
      } catch (error) {
        return reject(error);
      }
    });
  };
  exports.listUser = async function () {
    return new Promise(async (resolve, reject) => {
      try {
        const data = await Employee.find();
  
        return resolve({
          data: data,
          statusCode: 201,
          
        });
      } catch (error) {
        return reject(error);
      }
    });
  };
    //edit user
/*exports.editUser = async function (data) {
    return new Promise(async (resolve, reject) => {
      try {
        const user = await Employee.updateOne({
          _id: data,
          item:item
        });
        return resolve(user);
      } catch (error) {
        return reject(error);
      }
    });
  };*/
  exports.editUser= async function (id, data) {
    console.log(data);
    return new Promise(async (resolve, reject) => {
      try {
        const cat = await Employee.findByIdAndUpdate(id, data);
  
        return resolve({
          data: cat,
          statusCode: 201,
          success: true,
        });
      } catch (error) {
        return reject(error);
      }
    });
  };
  
  //Read
exports.getUser = async function (id) {
  return new Promise(async (resolve, reject) => {
    try {
      let user = await Employee.findOne({ _id: id });
      return resolve(user);
    } catch (error) {
      return reject(error);
    }
  });
};
  exports.deleteUser = async function (data) {
    return new Promise(async (resolve, reject) => {
      try {
        const user = await Employee.deleteOne({
          _id: data
        });
        return resolve(user);
      } catch (error) {
        return reject(error);
      }
    });
  };