const express = require("express");
const router = express.Router();


const userController = require("../controllers/userController");

// Add Create
router.get(
  "/",
  userController.index
);
router.post(
    "/",
    userController.addUser
  );
  router.get(
    "/users/list",
    userController.listUser
  );
  //Edit users
router.get(
    "/users/edit/:id",
    userController.editUser
  );
  router.post(
    "/users/edit/:id",
    userController.editUser
  );
  //Delete
router.get(
    "/delete/:id",
    userController.deleteUser
  );
  
module.exports =router;