const db = require('../helpers/app/userHelper');
const Employee = require('../models/user');

exports.index = (req, res) => {
    return res.render('users/register', {
      user: 'Admin',
      title:'Add Registration'
    });
  };
  // Add (Create)
exports.addUser = async (req, res) => {
    try {
      if (req.method === 'POST') {
        const user = {
          name: req.body.name,
          email: req.body.email,
          mobile: req.body.mobile,
          city: req.body.city,
          image: req.body.file
          
        };
        const userData = await db.addUser(user);
        if (userData) {
         console.log("user added")
        } else {
          console.log('error in user add')
        }
        res.redirect('users/list');
      } else {
        return res.render('users/register', {
          title: 'Add User',
          //name: req.user.name,
        });
      }
    } catch (error) {
      //req.flash('errors', {
       // msg: 'oops some error occured'
      console.log(error);
      return res.redirect(req.url);
    }
  };

  exports.listUser = async (req, res) => {
    try {
      let items = [];
      const catList = await db.listUser();
      catList.data.forEach((element) => {
        items.push({
            id: element._id,
          name: element.name, 
          email: element.email,
          mobile: element.mobile,
          city: element.city,
          image: element.file
          
        });
      });
      return res.render('users/list', {
        title: 'List',
        //name: req.user.name,
        data: items,
      });
    } catch (error) {
       // return res.redirect(req.url);
    }
  };
 //update

 exports.editUser = async (req, res) => {
  try {
    if (req.method === 'POST') {
      let data = req.body;

      let status = await db.editUser(req.params.id, data);
      if (status.success) {       
          return res.redirect('/users/list');
      }
    } else {
      let userData = await db.getUser(req.params.id);

      return res.render('users/edit', {
        title: 'Edit user',
        //name: req.user.name,
        id: userData._id,
        name: userData.name,
        email: userData.email,
        mobile:userData.mobile,
        city:userData.city
      });
    }
  } catch (error) {
    console.log(error);
    
      console.log('oops some error occured');
    return res.redirect(req.url);
  }
};


  //Delete

exports.deleteUser = async (req, res) => {
    try {
      var status = await db.deleteUser(req.params.id);
      if (status) {
          console.log("removed successfully")
        return res.redirect('/users/list');
      }
        } catch (error) {
      console.log(error);
      return res.redirect(req.url);
    }
  };