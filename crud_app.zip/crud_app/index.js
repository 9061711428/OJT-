const express=require('express');
const dotenv = require('dotenv');
const expressHbs = require('express-handlebars');
const path = require('path');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const multer=require('multer');
const userRoutes = require('./routes/user.routes');


//For .env
dotenv.config({
    path: '.env',
  });

var app=express();

/* Connect to MongoDB.
*/
mongoose.set('useFindAndModify', false);
mongoose.set('useCreateIndex', true);
mongoose.set('useNewUrlParser', true);
mongoose.set('useUnifiedTopology', true);
mongoose.connect(process.env.MONGODB_URI);
mongoose.connection.on('error', (err) => {
 console.error(err);
 console.log(
   '%s MongoDB connection error. Please make sure MongoDB is running.',
 );
 process.exit();
});

//Middleware
 app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);
//view engine
app.set('views', path.join(__dirname, 'views'));
app.engine(
  '.hbs',
  expressHbs({
    layoutsDir: './views/layouts',
    defaultLayout: 'layout',
    extname: '.hbs',
  })
);
app.set('view engine', '.hbs');
app.use(express.static('public')); //add public folder

var Storage=

app.use('/', userRoutes);

  app.listen(3000,()=>{
      console.log('server ruuning at port 3000');
  });
